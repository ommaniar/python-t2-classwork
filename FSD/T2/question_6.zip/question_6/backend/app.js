// write a express js script to print message in next line splitting by "." . Use get method to submit the data. html file contains form of text area for the message and submit button ur html file is in frontend folder and js file is in backend folder
const express = require("express");
const app = express();
const path = require("path");
sn = path.join(__dirname,"../frontend");
app.get("/",(req,res)=>{
    res.sendFile(sn+"/form.html");
})
app.get("/process-get",(req,res)=>{
    res.set("Content-Type","text/html");

    msg = req.query.msg.split(".");
    console.log(msg);
    for(i of msg){
        res.write(i + "<br>");
    }
    res.end()
})
app.listen(3000,()=>{
    console.log("App running at http://localhost:3000");
});
